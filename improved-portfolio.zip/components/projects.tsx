import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { ExternalLink, Github } from "lucide-react"

export function Projects() {
  const projects = [
    {
      title: "Real-time Data Pipeline",
      description:
        "Built a scalable real-time data processing pipeline using Apache Kafka, Spark Streaming, and AWS services to handle millions of events per day.",
      technologies: ["Apache Kafka", "Spark", "AWS", "Python", "Docker"],
      liveUrl: "#",
      githubUrl: "#",
    },
    {
      title: "ETL Workflow Automation",
      description:
        "Designed and implemented automated ETL workflows using Apache Airflow, reducing data processing time by 60% and improving reliability.",
      technologies: ["Apache Airflow", "PostgreSQL", "Python", "AWS S3", "Terraform"],
      liveUrl: "#",
      githubUrl: "#",
    },
    {
      title: "Big Data Analytics Dashboard",
      description:
        "Created an interactive analytics dashboard for big data visualization using React, D3.js, and Elasticsearch for real-time insights.",
      technologies: ["React", "D3.js", "Elasticsearch", "Node.js", "AWS"],
      liveUrl: "#",
      githubUrl: "#",
    },
    {
      title: "Cloud Infrastructure Optimization",
      description:
        "Optimized cloud infrastructure costs by 40% through automated scaling, resource monitoring, and performance tuning across multiple AWS services.",
      technologies: ["AWS", "Terraform", "CloudWatch", "Lambda", "Python"],
      liveUrl: "#",
      githubUrl: "#",
    },
    {
      title: "Data Lake Architecture",
      description:
        "Architected and deployed a serverless data lake solution on AWS, enabling efficient storage and querying of petabyte-scale datasets.",
      technologies: ["AWS S3", "AWS Glue", "Athena", "Lambda", "CloudFormation"],
      liveUrl: "#",
      githubUrl: "#",
    },
    {
      title: "Machine Learning Pipeline",
      description:
        "Built an end-to-end ML pipeline for predictive analytics, from data ingestion to model deployment, using MLOps best practices.",
      technologies: ["Python", "Scikit-learn", "MLflow", "Docker", "Kubernetes"],
      liveUrl: "#",
      githubUrl: "#",
    },
  ]

  return (
    <section className="py-20 px-4 bg-black relative">
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_top,rgba(59,130,246,0.1)_0%,transparent_50%)]" />

      <div className="max-w-6xl mx-auto relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4 neon-text">Featured Projects</h2>
          <p className="text-xl text-gray-300">A curated selection of cloud-based data engineering projects</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <Card
              key={index}
              className="bg-gray-900/40 border-gray-800 neon-border hover:neon-glow transition-all duration-300 backdrop-blur-sm group"
            >
              <CardHeader>
                <CardTitle className="text-xl text-white group-hover:text-blue-400 transition-colors duration-300">
                  {project.title}
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-300 text-sm leading-relaxed">{project.description}</p>

                <div className="flex flex-wrap gap-2">
                  {project.technologies.map((tech, techIndex) => (
                    <Badge
                      key={techIndex}
                      variant="outline"
                      className="text-xs border-blue-600/50 text-blue-300 hover:bg-blue-900/30 hover:neon-glow transition-all duration-300"
                    >
                      {tech}
                    </Badge>
                  ))}
                </div>

                <div className="flex gap-2 pt-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className="flex-1 border-blue-400 text-blue-400 hover:bg-blue-400 hover:text-black neon-border hover:neon-glow transition-all duration-300 bg-transparent"
                  >
                    <ExternalLink className="w-4 h-4 mr-2" />
                    Live Demo
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    className="flex-1 border-cyan-400 text-cyan-400 hover:bg-cyan-400 hover:text-black neon-border hover:neon-glow transition-all duration-300 bg-transparent"
                  >
                    <Github className="w-4 h-4 mr-2" />
                    Code
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
