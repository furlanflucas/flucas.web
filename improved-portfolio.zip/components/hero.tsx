import { Button } from "@/components/ui/button"
import { ArrowDown, Github, Linkedin, Mail } from "lucide-react"

export function Hero() {
  return (
    <section className="min-h-screen flex items-center justify-center px-4 relative overflow-hidden bg-black">
      {/* Animated background grid */}
      <div className="absolute inset-0 bg-[linear-gradient(rgba(59,130,246,0.1)_1px,transparent_1px),linear-gradient(90deg,rgba(59,130,246,0.1)_1px,transparent_1px)] bg-[size:50px_50px]" />

      {/* Neon orbs */}
      <div className="absolute top-20 left-20 w-72 h-72 bg-blue-500/30 rounded-full blur-3xl animate-pulse" />
      <div
        className="absolute bottom-20 right-20 w-96 h-96 bg-cyan-500/20 rounded-full blur-3xl animate-pulse"
        style={{ animationDelay: "1s" }}
      />
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] bg-blue-600/10 rounded-full blur-3xl" />

      <div className="max-w-4xl mx-auto text-center relative z-10">
        <div className="mb-8">
          <div className="w-32 h-32 mx-auto mb-6 rounded-full bg-gradient-to-r from-blue-500 to-cyan-400 flex items-center justify-center text-black text-4xl font-bold neon-glow-strong animate-pulse">
            FL
          </div>
          <h1 className="text-5xl md:text-7xl font-bold text-white mb-4 neon-text">Lucas Furlan</h1>
          <p className="text-xl md:text-2xl text-blue-400 mb-2 font-semibold">
            Cloud Data Engineer & Big Data Specialist
          </p>
          <p className="text-lg text-gray-300 max-w-2xl mx-auto leading-relaxed">
            Designing and deploying scalable data pipelines with modern cloud technologies to create interactive
            experiences for data-driven insights.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
          <Button
            size="lg"
            className="bg-blue-600 hover:bg-blue-500 text-white neon-glow hover:neon-glow-strong transition-all duration-300 border border-blue-400"
          >
            <Mail className="w-4 h-4 mr-2" />
            Get In Touch
          </Button>
          <Button
            size="lg"
            variant="outline"
            className="border-blue-400 text-blue-400 hover:bg-blue-400 hover:text-black neon-border hover:neon-glow transition-all duration-300 bg-transparent"
          >
            <Github className="w-4 h-4 mr-2" />
            View Projects
          </Button>
        </div>

        <div className="flex justify-center space-x-8">
          <a
            href="#"
            className="text-gray-400 hover:text-blue-400 transition-colors duration-300 hover:neon-glow p-2 rounded-full"
          >
            <Github className="w-7 h-7" />
          </a>
          <a
            href="#"
            className="text-gray-400 hover:text-blue-400 transition-colors duration-300 hover:neon-glow p-2 rounded-full"
          >
            <Linkedin className="w-7 h-7" />
          </a>
          <a
            href="#"
            className="text-gray-400 hover:text-blue-400 transition-colors duration-300 hover:neon-glow p-2 rounded-full"
          >
            <Mail className="w-7 h-7" />
          </a>
        </div>
      </div>

      <div className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce">
        <ArrowDown className="w-6 h-6 text-blue-400 neon-glow" />
      </div>
    </section>
  )
}
