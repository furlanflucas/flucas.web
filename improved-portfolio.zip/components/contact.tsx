import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Mail, MapPin, Phone, Send } from "lucide-react"

export function Contact() {
  return (
    <section className="py-20 px-4 bg-black relative">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_bottom,rgba(59,130,246,0.2)_0%,transparent_50%)]" />

      <div className="max-w-6xl mx-auto relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4 neon-text">Get In Touch</h2>
          <p className="text-xl text-gray-300">
            Ready to collaborate on your next data engineering project? Let's talk!
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          <div className="space-y-8">
            <div>
              <h3 className="text-2xl font-semibold text-white mb-4">Let's work together</h3>
              <p className="text-gray-300 mb-6 leading-relaxed">
                I'm always interested in discussing new opportunities, collaborations, or just chatting about data
                engineering and cloud technologies.
              </p>
            </div>

            <div className="space-y-6">
              <div className="flex items-center space-x-4 p-4 rounded-lg bg-gray-900/30 border border-gray-800 neon-border">
                <Mail className="w-6 h-6 text-blue-400 neon-glow" />
                <span className="text-gray-300">lucas@flucasio.com</span>
              </div>
              <div className="flex items-center space-x-4 p-4 rounded-lg bg-gray-900/30 border border-gray-800 neon-border">
                <MapPin className="w-6 h-6 text-cyan-400 neon-glow" />
                <span className="text-gray-300">Available for remote work</span>
              </div>
              <div className="flex items-center space-x-4 p-4 rounded-lg bg-gray-900/30 border border-gray-800 neon-border">
                <Phone className="w-6 h-6 text-blue-300 neon-glow" />
                <span className="text-gray-300">Available upon request</span>
              </div>
            </div>
          </div>

          <Card className="bg-gray-900/40 border-gray-800 neon-border backdrop-blur-sm">
            <CardHeader>
              <CardTitle className="text-blue-400">Send me a message</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="firstName" className="text-gray-300">
                    First Name
                  </Label>
                  <Input
                    id="firstName"
                    placeholder="John"
                    className="bg-black/50 border-gray-700 text-white placeholder:text-gray-500 focus:border-blue-400 focus:neon-glow"
                  />
                </div>
                <div className="space-y-2">
                  <Label htmlFor="lastName" className="text-gray-300">
                    Last Name
                  </Label>
                  <Input
                    id="lastName"
                    placeholder="Doe"
                    className="bg-black/50 border-gray-700 text-white placeholder:text-gray-500 focus:border-blue-400 focus:neon-glow"
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="email" className="text-gray-300">
                  Email
                </Label>
                <Input
                  id="email"
                  type="email"
                  placeholder="john@example.com"
                  className="bg-black/50 border-gray-700 text-white placeholder:text-gray-500 focus:border-blue-400 focus:neon-glow"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="subject" className="text-gray-300">
                  Subject
                </Label>
                <Input
                  id="subject"
                  placeholder="Project collaboration"
                  className="bg-black/50 border-gray-700 text-white placeholder:text-gray-500 focus:border-blue-400 focus:neon-glow"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="message" className="text-gray-300">
                  Message
                </Label>
                <Textarea
                  id="message"
                  placeholder="Tell me about your project..."
                  rows={5}
                  className="bg-black/50 border-gray-700 text-white placeholder:text-gray-500 focus:border-blue-400 focus:neon-glow resize-none"
                />
              </div>

              <Button className="w-full bg-blue-600 hover:bg-blue-500 text-white neon-glow hover:neon-glow-strong transition-all duration-300 border border-blue-400">
                <Send className="w-4 h-4 mr-2" />
                Send Message
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
