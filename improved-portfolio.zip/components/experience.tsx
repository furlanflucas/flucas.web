import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

export function Experience() {
  const experiences = [
    {
      title: "Senior Data Engineer",
      company: "Tech Company",
      period: "2022 - Present",
      description:
        "Leading cloud architecture and data processing initiatives, designing scalable ETL pipelines, and optimizing infrastructure for performance.",
      achievements: [
        "Reduced data processing time by 60% through pipeline optimization",
        "Architected serverless data lake handling 10TB+ daily",
        "Led team of 5 engineers in cloud migration project",
      ],
    },
    {
      title: "Cloud Data Engineer",
      company: "Data Solutions Inc",
      period: "2020 - 2022",
      description:
        "Developed and maintained big data solutions, implemented real-time streaming architectures, and collaborated on infrastructure optimization.",
      achievements: [
        "Built real-time analytics platform processing 1M+ events/day",
        "Implemented automated monitoring reducing downtime by 80%",
        "Optimized cloud costs by 40% through resource management",
      ],
    },
    {
      title: "Junior Data Engineer",
      company: "StartupTech",
      period: "2019 - 2020",
      description:
        "Focused on ETL development, data quality assurance, and supporting analytics initiatives for business intelligence.",
      achievements: [
        "Developed 15+ ETL workflows using Apache Airflow",
        "Improved data quality metrics by 95%",
        "Created automated reporting dashboards",
      ],
    },
  ]

  return (
    <section className="py-20 px-4 bg-gray-950 relative">
      <div className="absolute inset-0 bg-[conic-gradient(from_0deg_at_50%_50%,rgba(59,130,246,0.1)_0deg,transparent_60deg,transparent_300deg,rgba(59,130,246,0.1)_360deg)]" />

      <div className="max-w-4xl mx-auto relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4 neon-text">Experience & Skills</h2>
          <p className="text-xl text-gray-300">
            My background in cloud architecture, data processing, and infrastructure optimization
          </p>
        </div>

        <div className="space-y-8">
          {experiences.map((exp, index) => (
            <Card
              key={index}
              className="bg-black/60 border-gray-800 neon-border hover:neon-glow transition-all duration-300 backdrop-blur-sm"
            >
              <CardHeader>
                <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                  <div>
                    <CardTitle className="text-xl text-white mb-1">{exp.title}</CardTitle>
                    <p className="text-lg text-blue-400 font-medium">{exp.company}</p>
                  </div>
                  <Badge variant="outline" className="mt-2 md:mt-0 border-cyan-400 text-cyan-400 neon-glow">
                    {exp.period}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-gray-300 leading-relaxed">{exp.description}</p>

                <div>
                  <h4 className="font-semibold text-blue-400 mb-3">Key Achievements:</h4>
                  <ul className="space-y-2">
                    {exp.achievements.map((achievement, achIndex) => (
                      <li key={achIndex} className="text-gray-300 text-sm flex items-start">
                        <span className="text-cyan-400 mr-3 text-lg">▸</span>
                        {achievement}
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
