import { Card, CardContent } from "@/components/ui/card"
import { Database, Cloud, BarChart3, Zap } from "lucide-react"

export function About() {
  const highlights = [
    {
      icon: <Database className="w-8 h-8 text-blue-400" />,
      title: "Data Engineering",
      description: "Building robust ETL pipelines and data architectures",
    },
    {
      icon: <Cloud className="w-8 h-8 text-cyan-400" />,
      title: "Cloud Architecture",
      description: "Designing scalable solutions on AWS and other platforms",
    },
    {
      icon: <BarChart3 className="w-8 h-8 text-blue-300" />,
      title: "Big Data Analytics",
      description: "Processing and analyzing large-scale datasets",
    },
    {
      icon: <Zap className="w-8 h-8 text-cyan-300" />,
      title: "Performance Optimization",
      description: "Optimizing infrastructure for maximum efficiency",
    },
  ]

  return (
    <section className="py-20 px-4 bg-black relative">
      <div className="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(59,130,246,0.1)_0%,transparent_50%)]" />

      <div className="max-w-6xl mx-auto relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4 neon-text">About Me</h2>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto leading-relaxed">
            I specialize in Cloud Data Engineering, Big Data, and Scalable Data Pipelines. With expertise in modern
            front-end and cloud technologies, I create interactive experiences that bring data to life.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {highlights.map((item, index) => (
            <Card
              key={index}
              className="bg-gray-900/50 border-gray-800 neon-border hover:neon-glow transition-all duration-300 backdrop-blur-sm"
            >
              <CardContent className="p-6 text-center">
                <div className="mb-4 flex justify-center neon-glow rounded-full p-2 w-fit mx-auto">{item.icon}</div>
                <h3 className="text-lg font-semibold text-white mb-2">{item.title}</h3>
                <p className="text-gray-400 text-sm leading-relaxed">{item.description}</p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
