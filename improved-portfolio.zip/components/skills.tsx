import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

export function Skills() {
  const skillCategories = [
    {
      title: "Cloud Platforms",
      skills: ["AWS", "AWS Amplify", "Azure", "Google Cloud", "Serverless"],
    },
    {
      title: "Data Engineering",
      skills: ["Apache Spark", "Kafka", "Airflow", "ETL Pipelines", "Data Lakes"],
    },
    {
      title: "Big Data Technologies",
      skills: ["Hadoop", "Elasticsearch", "MongoDB", "PostgreSQL", "Redis"],
    },
    {
      title: "Programming Languages",
      skills: ["Python", "JavaScript", "SQL", "Scala", "Java"],
    },
    {
      title: "Frontend Technologies",
      skills: ["React", "Next.js", "TypeScript", "HTML5", "CSS3", "SCSS"],
    },
    {
      title: "DevOps & Tools",
      skills: ["Docker", "Kubernetes", "CI/CD", "Terraform", "Git"],
    },
  ]

  return (
    <section className="py-20 px-4 bg-gray-950 relative">
      <div className="absolute inset-0 bg-[linear-gradient(45deg,rgba(59,130,246,0.05)_25%,transparent_25%),linear-gradient(-45deg,rgba(59,130,246,0.05)_25%,transparent_25%)] bg-[size:60px_60px]" />

      <div className="max-w-6xl mx-auto relative z-10">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-4 neon-text">Tech Stack</h2>
          <p className="text-xl text-gray-300">Technologies and tools I work with to build scalable data solutions</p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {skillCategories.map((category, index) => (
            <Card
              key={index}
              className="bg-black/60 border-gray-800 neon-border hover:neon-glow transition-all duration-300 backdrop-blur-sm"
            >
              <CardHeader>
                <CardTitle className="text-lg text-blue-400 font-semibold">{category.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="flex flex-wrap gap-2">
                  {category.skills.map((skill, skillIndex) => (
                    <Badge
                      key={skillIndex}
                      variant="secondary"
                      className="bg-blue-900/30 text-blue-300 hover:bg-blue-800/50 border border-blue-600/30 hover:neon-glow transition-all duration-300"
                    >
                      {skill}
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
